<?php
namespace phpGrace\models;
use OSS\OssClient;
use OSS\Core\OssException;
//阿里 OOS 配置
define('OSS_ACCESS_ID',  '******');
define('OSS_ACCESS_KEY', '******');
define('OSS_HOST',       'http://oss-cn-beijing.aliyuncs.com/');
define('OSS_BUCKET',     'phpgrace');

function oosClassLoader($class){
    $path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    $file = __DIR__ .DIRECTORY_SEPARATOR.$path . '.php';
    if (file_exists($file)) {require_once $file;}
}

spl_autoload_register('phpGrace\models\oosClassLoader');

class alioos{
	
	public $oos = null;
	
	public function __construct(){
		$this->config = sc();
		$this->oos = new OssClient(OSS_ACCESS_ID, OSS_ACCESS_KEY, OSS_HOST, false);
	}
	
	public function toOos($localUrl, $oosUrl, $removeLocalFile = true){
		if($this->oos == null){return false;}
		$this->oos->uploadFile(OSS_BUCKET, $oosUrl, $localUrl);
		if($removeLocalFile){@unlink($localUrl);}
	}
	
	public function remove($fileUrl, $localUrl = false){
		if($this->oos == null){return false;}
		$this->oos->deleteObject(OSS_BUCKET, $fileUrl);
		if($localUrl){
			if(is_file($localUrl)){@unlink($localUrl);}
		}
	}
}